default_app_config = 'search.engines.haystack.apps.HaystackConfig'
