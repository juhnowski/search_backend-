from django.apps import AppConfig


class HaystackConfig(AppConfig):
    name = 'haystack'
    verbose_name = 'Поисковый движок haystack'
