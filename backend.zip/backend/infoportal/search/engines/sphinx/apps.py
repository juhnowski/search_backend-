from django.apps import AppConfig


class SphinxConfig(AppConfig):
    name = 'sphinx'
    verbose_name = 'sphinxsearch поисковый движок'
