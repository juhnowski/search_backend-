default_app_config = 'search.engines.simple.apps.SphinxConfig'
