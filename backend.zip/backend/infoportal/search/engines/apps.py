from django.apps import AppConfig


class EnginesConfig(AppConfig):
    name = 'engines'
    verbose_name = 'Поисковые движки'
