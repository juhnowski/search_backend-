from django.apps import AppConfig


class MySolrConfig(AppConfig):
    name = "solr"
    verbose_name = 'Solr поисковый движок'
