default_app_config = 'search.engines.solr.apps.MySolrConfig'
