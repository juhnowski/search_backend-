from django.apps import AppConfig


class ComparisonConfig(AppConfig):
    name = 'comparison'
    verbose_name = 'Сравнение'
