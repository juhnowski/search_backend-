Библиотека *.xsl файлов для преобразования *.xml в *.html

Для преобразования:
$ saxonb-xslt -ext:on -o:<имя_выходного_файла>.html -xsl:isosts2gosthtml_standalone_pnst.xsl -s:<имя_исходного файла>.xml
