from django.apps import AppConfig


class IntegrationConfig(AppConfig):
    name = 'integration'
    verbose_name = 'Интеграция'
