default_app_config = 'documents.apps.NotesConfig'
